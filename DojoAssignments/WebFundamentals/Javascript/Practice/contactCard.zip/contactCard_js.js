
// function getHiddenDescription() {
// 	$(this)click(function(){
// 		var description = $(this).attr('p');
// 	})
// }
// 	$("img").click(function() {
// 		var background = $(this).attr("alt-src");
// 		$(this).attr('src', background);
// 		var background2 = $(this).attr("src");
// 		$("img").html('alt-src', background2);
// });


$(document).ready(function() {

	$("button").click(function(){
		var first = $('#1').val();
		var last = $('#2').val();
		var description = $('#3').val();
		$('#users').append('<div id ="card" ><p>' +first+ ' ' +last+ '</p><p id= "back"> ' +description+ '</p></div>');
		return false;
	});

	$(document).on('click', '#card', function(){
		$(this).children().toggle();
	});
	
	// $('#submit_form').click(function(){ 
	// 	var newline = "<h5>" +$('form').find('#1').val()+ " " +$('form').find('#2').val()+ "</h5><p>" +$('form').find('#3').val()+ "</p>""$(";
	// 	$('#users').append(newline);
	// });

});