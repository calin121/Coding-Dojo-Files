
$(document).ready(function() {

	$('#submit_form').click(function(){ 
		var newline = "<tr><td>" +$('form').find('#1').val()+ "</td><td>" +$('form').find('#2').val()+ "</td><td>" +$('form').find('#3').val()+ "</td><td>" +$('form').find('#4').val()+ "</td></tr>";
		$('#enter_data').append(newline);
	});
});